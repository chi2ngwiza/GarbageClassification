
```markdown
# Streamlit App for Garbage Detection Model

This project contains a Streamlit-based application that serves as a front-end ui for Garbage Detection Model that was trained using TACO dataset.

## Features
- Upload images and detect Garbage using a ML pretrained model.
- Visualize predictions and feature extractions.

## Requirements
- Python 3.8 or higher
- Streamlit 1.11.0 or higher
- Dependencies listed in `requirements.txt`

   ```
1. **Connect to Internet:**

2. **Set up a virtual environment (optional but recommended):**
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install the dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

## Running the App

1. **Launch the Streamlit app:**
   ```bash
   streamlit run main.py --server.enableXsrfProtection=false
   ```

2. **Open the app in your browser:**
   Once the app starts, you will see a URL in the terminal (e.g., `http://localhost:8501`). Open this URL in your browser to use the app.

## Usage

- **Upload an Image:** Use the app's file uploader to select an image for analysis.
- **View Results:** The app will display predictions and extracted features

## File Structure
```plaintext
.
├── main.py                        # Main Streamlit app script
├── requirements.txt               # Python dependencies
├── README.md                      # Instructions and documentation
└── training_using_taco_dataset/   # Folder for model traing, TACO dataset and visualizations
```
