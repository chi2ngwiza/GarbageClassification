from flask import Flask, request, jsonify
import pickle
from PIL import Image
import numpy as np

app = Flask(__name__)

# Load the model
with open('garbage_detection_model.pkl', 'rb') as f:
    model = pickle.load(f)

@app.route('/predict', methods=['POST'])
def predict():
    image_data = request.files['image']
    img = Image.open(image_data)
    img_array = np.array(img)
    # Preprocess as needed
    
    prediction = model.predict(img_array)
    
    return jsonify({"prediction": str(prediction)})

if __name__ == "__main__":
    app.run(debug=True)
