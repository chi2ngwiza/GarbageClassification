import pickle
import sys
from PIL import Image
import numpy as np

# Load the model
with open('garbage_detection_model.pkl', 'rb') as f:
    model = pickle.load(f)

def process_image(image_path):
    # Load and preprocess the image
    img = Image.open(image_path)
    img_array = np.array(img)
    # Preprocess as needed (e.g., resize, normalize)
    
    # Use the model to make predictions
    prediction = model.predict(img_array)
    
    return prediction

if __name__ == "__main__":
    image_path = sys.argv[1]
    result = process_image(image_path)
    print(result)
