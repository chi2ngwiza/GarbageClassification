import numpy as np

# Define the ReLU activation function
def relu(x):
    return np.maximum(0, x)

# Simple 2D convolution
def conv2d(input, kernel, stride=1, padding=0):
    input_padded = np.pad(input, ((padding, padding), (padding, padding), (0, 0)), mode='constant')
    kernel_h, kernel_w, in_channels, out_channels = kernel.shape
    input_h, input_w, _ = input_padded.shape

    output_h = (input_h - kernel_h) // stride + 1
    output_w = (input_w - kernel_w) // stride + 1

    output = np.zeros((output_h, output_w, out_channels))

    for i in range(0, output_h):
        for j in range(0, output_w):
            region = input_padded[i * stride:i * stride + kernel_h, j * stride:j * stride + kernel_w, :]
            for k in range(out_channels):
                output[i, j, k] = np.sum(region * kernel[:, :, :, k])

    return output

# Batch normalization
def batch_norm(x, gamma, beta, epsilon=1e-5):
    mean = np.mean(x, axis=(0, 1, 2), keepdims=True)
    variance = np.var(x, axis=(0, 1, 2), keepdims=True)
    x_normalized = (x - mean) / np.sqrt(variance + epsilon)
    return gamma * x_normalized + beta

# Residual block with skip connection
def residual_block(input, kernels, gamma, beta, stride=1):
    conv1 = conv2d(input, kernels[0], stride=stride, padding=1)
    bn1 = batch_norm(conv1, gamma[0], beta[0])
    relu1 = relu(bn1)

    conv2 = conv2d(relu1, kernels[1], stride=1, padding=1)
    bn2 = batch_norm(conv2, gamma[1], beta[1])

    # Skip connection
    shortcut = input
    if stride != 1 or input.shape[-1] != kernels[1].shape[-1]:
        shortcut = conv2d(input, kernels[2], stride=stride, padding=0)

    return relu(bn2 + shortcut)

# ResNet50
class ResNet50:
    def __init__(self):
        self.kernels = []  # Store convolutional kernels
        self.gammas = []   # Store gamma for batch normalization
        self.betas = []    # Store beta for batch normalization

    def add_layer(self, kernel_shapes):
        self.kernels.append([np.random.randn(*shape) for shape in kernel_shapes])
        self.gammas.append([np.ones(shape[-1]) for shape in kernel_shapes])
        self.betas.append([np.zeros(shape[-1]) for shape in kernel_shapes])

    def forward(self, x):
        for i in range(len(self.kernels)):
            x = residual_block(x, self.kernels[i], self.gammas[i], self.betas[i])
        return x
